function loadFrame(elm) {
    var frame1 = document.getElementById('frame1');
    frame1.src = elm.dataset.src;
}